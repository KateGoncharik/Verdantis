export * from './product-paper';
