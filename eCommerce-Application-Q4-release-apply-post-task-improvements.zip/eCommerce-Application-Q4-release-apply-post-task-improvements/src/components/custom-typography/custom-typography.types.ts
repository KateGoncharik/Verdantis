export type ComponentType = keyof HTMLElementTagNameMap;
