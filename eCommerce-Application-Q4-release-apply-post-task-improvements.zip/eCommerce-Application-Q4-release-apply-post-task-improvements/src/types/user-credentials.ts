export type UserCredentials = {
  password: string;
  username: string;
};
