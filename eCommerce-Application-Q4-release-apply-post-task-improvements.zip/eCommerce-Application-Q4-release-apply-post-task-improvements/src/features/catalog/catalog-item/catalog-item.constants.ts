export const discountPriceStyleCatalog = {
  color: 'grey.400',
  textDecoration: 'line-through',
};

export const stylePriceCatalog = 'primary';

export const firstVariantPrice = 0;
