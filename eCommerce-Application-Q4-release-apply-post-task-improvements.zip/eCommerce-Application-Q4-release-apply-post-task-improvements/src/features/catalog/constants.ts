export const notSelectedCategoryValue = '';
export const indexOfReceivedCategory = 0;
